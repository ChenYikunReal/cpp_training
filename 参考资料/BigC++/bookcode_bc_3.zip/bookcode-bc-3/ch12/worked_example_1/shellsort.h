void insertion_sort(int a[], int size, int k, int c);
void shell_sort(int a[], int size);

