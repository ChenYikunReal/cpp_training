#include "picture.h"

int main()
{
   Picture pic("a.png");
   
   pic.save("gallery.png");
   return 0;
}

